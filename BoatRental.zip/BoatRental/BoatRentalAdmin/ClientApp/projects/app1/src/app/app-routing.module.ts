import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { User1FormComponent } from './user1-form/user1-form.component';
import { User2FormComponent } from './user2-form/user2-form.component';
import { User3FormComponent } from './user3-form/user3-form.component';
import { User4FormComponent } from './user4-form/user4-form.component';
import { UserListComponent } from './user-list/user-list.component';

const routes: Routes = [
  { path: '', component: UserListComponent },
  // { path: 'user1', component: User1FormComponent },
  // { path: 'user2', component: User2FormComponent },
  // { path: 'user3', component: User3FormComponent },
  // { path: 'user4', component: User4FormComponent },
  { path: '**', redirectTo: '' }];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

