import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { User1FormComponent } from './user1-form/user1-form.component';
import { User2FormComponent } from './user2-form/user2-form.component';
import { User3FormComponent } from './user3-form/user3-form.component';
import { User4FormComponent } from './user4-form/user4-form.component';
import { UserListComponent } from './user-list/user-list.component';

@NgModule({
  declarations: [
    AppComponent,
    User1FormComponent,
    User2FormComponent,
    User3FormComponent,
    User4FormComponent,
    UserListComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
