import { Component, OnInit } from '@angular/core';
import { User1FormComponent } from '../user1-form/user1-form.component';

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.css']
})
export class UserListComponent implements OnInit {

  hideList: boolean;
  hideUser1Form: boolean;
  hideUser2Form: boolean;
  hideUser3Form: boolean;
  hideUser4Form: boolean;
  constructor() {
    this.hideList = true;
    this.hideUser1Form = false;
    this.hideUser2Form = false;
    this.hideUser3Form = false;
    this.hideUser4Form = false;
  }

  ngOnInit(): void {
  }

  userListClick(userType: string) {
    this.hideList = false;
    switch (userType) {
      case 'user1':
        this.hideUser1Form = true;
        break;
      case 'user2':
        this.hideUser2Form = true;
        break;
      case 'user3':
        this.hideUser3Form = true;
        break;
      case 'user4':
        this.hideUser4Form = true;
        break;
    }
  }
}
