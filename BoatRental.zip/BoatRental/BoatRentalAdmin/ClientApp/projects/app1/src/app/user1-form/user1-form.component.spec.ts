import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { User1FormComponent } from './user1-form.component';

describe('User1FormComponent', () => {
  let component: User1FormComponent;
  let fixture: ComponentFixture<User1FormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ User1FormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(User1FormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
