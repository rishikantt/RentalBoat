import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators, AbstractControl } from '@angular/forms';

@Component({
  selector: 'app-user1-form',
  templateUrl: './user1-form.component.html',
  styleUrls: ['./user1-form.component.css']
})
export class User1FormComponent implements OnInit {
  basicForm: FormGroup;
  isMessage: boolean;
  message: any;
  boatNumber: Number;

  constructor(public formBuilder: FormBuilder) {
    this.isMessage = false;
    this.message = "";
    this.basicForm = this.formBuilder.group({
      boatName: new FormControl('', Validators.required),
      boatImage: new FormControl('', Validators.required),
      boatRate: new FormControl('', Validators.required),
      boatNumber: new FormControl()
    });
  }

  async basicSubmit() {
    let url = window.location.href + 'Home/RegisterBoat';
    let res = await new Promise((res) => {
      fetch(url, {
        method: "POST",
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          BoatName: this.basicForm.value.boatName,
          BoatImage: this.basicForm.value.boatImage,
          BoatRate: this.basicForm.value.boatRate
        })
      }).then(response => {
        res(response.json());
      });
    });
    if (res["success"]) {
      this.boatNumber = res["id"];
    } else {
      this.isMessage = true;
      this.message = res["message"];
    }
  }

  backButtonClick() {
    const href = window.location.href;
    window.location.href = href;
  }

  ngOnInit(): void {
  }

}
