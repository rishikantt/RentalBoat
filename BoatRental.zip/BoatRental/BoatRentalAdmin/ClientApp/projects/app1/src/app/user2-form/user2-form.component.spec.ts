import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { User2FormComponent } from './user2-form.component';

describe('User2FormComponent', () => {
  let component: User2FormComponent;
  let fixture: ComponentFixture<User2FormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ User2FormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(User2FormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
