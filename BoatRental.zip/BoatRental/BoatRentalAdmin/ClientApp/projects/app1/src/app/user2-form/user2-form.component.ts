import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-user2-form',
  templateUrl: './user2-form.component.html',
  styleUrls: ['./user2-form.component.css']
})
export class User2FormComponent implements OnInit {
  basicForm: any;
  isMessage: boolean;
  message: string;

  constructor(public formBuilder: FormBuilder) {
    this.isMessage = false;
    this.message = "";
    this.basicForm = this.formBuilder.group({
      boatNumber: new FormControl('', Validators.required),
      customerName: new FormControl('', Validators.required)
    });
  }

  ngOnInit(): void {
  }

  async basicSubmit() {
    let url = window.location.href + 'Home/BookRent?boatNumber=' + this.basicForm.value.boatNumber +
      '&customerName=' + this.basicForm.value.customerName;
    let res = await new Promise((res) => {
      fetch(url, {
        method: "POST",
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json'
        }
      }).then(response => {
        res(response.json());
      });
    });
    if (!res["success"]) {
      this.isMessage = true;
      this.message = res["message"];
    }
  }

  backButtonClick() {
    const href = window.location.href;
    window.location.href = href;
  }

}
