import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { User3FormComponent } from './user3-form.component';

describe('User3FormComponent', () => {
  let component: User3FormComponent;
  let fixture: ComponentFixture<User3FormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ User3FormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(User3FormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
