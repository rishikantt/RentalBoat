import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-user4-form',
  templateUrl: './user4-form.component.html',
  styleUrls: ['./user4-form.component.css']
})
export class User4FormComponent implements OnInit {
  basicForm: any;
  isMessage: boolean;
  message: string;

  constructor(public formBuilder: FormBuilder) {
    this.isMessage = false;
    this.message = "";
    this.basicForm = this.formBuilder.group({
      boatNumber: new FormControl('', Validators.required)
    });
  }

  ngOnInit(): void {
  }

  async basicSubmit() {
    let url = window.location.href + 'Home/DeRegisterBoat?boatNumber=' + this.basicForm.value.boatNumber;
    let res = await new Promise((res) => {
      fetch(url, {
        method: "POST",
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json'
        }
      }).then(response => {
        res(response.json());
      });
    });
    this.isMessage = true;
    this.message = res["message"];
  }

  backButtonClick() {
    const href = window.location.href;
    window.location.href = href;
  }

}
