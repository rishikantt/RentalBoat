﻿using BoatRentalAdmin.Models;
using System;
using System.Linq;

namespace BoatRentalAdmin.Context
{
    public class HomeService
    {
        public int RegisterBoat(Boat boat)
        {
            using(RentalBoatDbContext db = new RentalBoatDbContext())
            {
                Boat newBoat = new Boat
                {
                    BoatName = boat.BoatName,
                    BoatImage = boat.BoatImage,
                    BoatRate = boat.BoatRate,
                    IsBoatRented = boat.IsBoatRented
                };
                db.Boats.Add(newBoat);
                db.SaveChanges();
                return newBoat.BoatId;
            }
        }

        public bool BookRent(int boatNumber, string customerName)
        {
            using(RentalBoatDbContext db = new RentalBoatDbContext())
            {
                Customer newCustomer = new Customer
                {
                    CustomerName = customerName
                };
                db.Customers.Add(newCustomer);
                db.SaveChanges();

                var result = db.Boats.SingleOrDefault(b => b.BoatId == boatNumber && !b.IsBoatRented);
                if(result != null)
                {
                    result.IsBoatRented = true;
                    result.BoatRentTime = new DateTime();
                    result.CustomerId = newCustomer.CustomerId;
                }
                db.SaveChanges();

                return result.IsBoatRented;
            }
        }

        public double BoatReturn(int boatNumber)
        {
            using(RentalBoatDbContext db = new RentalBoatDbContext())
            {
                double price = 0;
                var result = db.Boats.SingleOrDefault(b => b.BoatId == boatNumber && b.IsBoatRented);
                if(result != null)
                {
                    result.IsBoatRented = false;
                    price = result.BoatRate * (result.BoatRentTime - new DateTime()).TotalHours;
                }
                db.SaveChanges();

                return price;
            }
        }

        public bool DeRegisterBoat(int boatNumber)
        {
            using (RentalBoatDbContext db = new RentalBoatDbContext())
            {
                bool isBoatRemoved = false;
                var result = db.Boats.SingleOrDefault(b => b.BoatId == boatNumber && b.IsBoatRented);
                if (result != null)
                {
                    db.Boats.Remove(result);
                    isBoatRemoved = true;
                }
                db.SaveChanges();

                return isBoatRemoved;
            }
        }
    }
}
