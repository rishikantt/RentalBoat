﻿using BoatRentalAdmin.Context;
using BoatRentalAdmin.Models;
using Microsoft.AspNetCore.Mvc;
using System;

namespace BoatRentalAdmin.Controllers
{
    public class HomeController : Controller
    {
        HomeService services = new HomeService();
        public IActionResult Index()
        {
            return View();
        }

        /// <summary>
        /// Register Boat
        /// </summary>
        /// <param name="boat">Details of Boat.</param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult RegisterBoat(Boat boat)
        {
            try
            {
                boat.IsBoatRented = false;
                int boatId = services.RegisterBoat(boat);
                return Json(new
                {
                    success = true,
                    id = boatId,
                    message = ""
                });
            }
            catch(Exception ex)
            {
                return Json(new
                {
                    success = false,
                    id = -1,
                    message = ex.Message
                });
            }
        }

        /// <summary>
        /// Book rent for boat.
        /// </summary>
        /// <param name="boatNumber">Boat Number</param>
        /// <param name="customerName">Customer Name.</param>
        /// <returns></returns>
        public JsonResult BookRent(int boatNumber, string customerName)
        {
            try
            {
                bool isRented = services.BookRent(boatNumber, customerName);
                return Json(new
                {
                    success = true,
                    isBoatRented = isRented,
                    message = isRented ? "" : "Boat is not present for rent"
                });
            }
            catch (Exception ex)
            {
                return Json(new
                {
                    success = false,
                    isBoatRented = false,
                    message = ex.Message
                });
            }
        }

        /// <summary>
        /// Return boat.
        /// </summary>
        /// <param name="boatNumber">Boat Number.</param>
        /// <returns></returns>
        public JsonResult BoatReturn(int boatNumber)
        {
            try
            {
                double rentPrice = services.BoatReturn(boatNumber);
                return Json(new
                {
                    success = true,
                    price = rentPrice,
                    message = rentPrice == 0 ? "" : "Boat is not rented"
                });
            }
            catch (Exception ex)
            {
                return Json(new
                {
                    success = false,
                    price = 0,
                    message = ex.Message
                });
            }
        }

        /// <summary>
        /// Remove boat.
        /// </summary>
        /// <param name="boatNumber">Boat Number.</param>
        /// <returns></returns>
        public JsonResult DeRegisterBoat(int boatNumber)
        {
            try
            {
                bool isRemoved = services.DeRegisterBoat(boatNumber);
                return Json(new
                {
                    success = true,
                    boatRemoved = isRemoved,
                    message = isRemoved ? "Boat is successfully removed" : "Boat is not present"
                });
            }
            catch (Exception ex)
            {
                return Json(new
                {
                    success = false,
                    boatRemoved = false,
                    message = ex.Message
                });
            }
        }

    }
}
