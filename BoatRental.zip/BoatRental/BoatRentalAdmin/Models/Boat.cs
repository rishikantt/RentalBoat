﻿using System;
using System.ComponentModel.DataAnnotations;

namespace BoatRentalAdmin.Models
{
    public class Boat
    {
        [Key]
        public int BoatId { get; set; }
        public string BoatName { get; set; }
        public string BoatImage { get; set; }
        public double BoatRate { get; set; }
        public DateTime BoatRentTime { get; set; }
        public bool IsBoatRented  { get; set; }
        public int CustomerId { get; set; }
    }
}
