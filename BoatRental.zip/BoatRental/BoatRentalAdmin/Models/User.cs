﻿using System.ComponentModel.DataAnnotations;

namespace BoatRentalAdmin.Models
{
    public class User
    {
        [Key]
        public long UserId { get; set; }
        public string UserName { get; set; }
        public string RoleName { get; set; }
    }
}
